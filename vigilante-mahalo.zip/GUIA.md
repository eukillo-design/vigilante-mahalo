# Cómo poner en marcha el vigilante de Mahalo Bermejales

Tiempo estimado: 15 minutos. Todo se hace desde la web de GitHub y desde Telegram.

## 1. Crear el bot de Telegram (si aún no lo has hecho)
1. En Telegram, busca **@BotFather** (con tick azul) y pulsa **Iniciar**.
2. Escribe `/newbot`. Ponle un nombre (`Alertas Mahalo`) y un usuario que acabe en `bot`.
3. Copia el **token** que te da (algo como `123456789:AAH...`). Es secreto: no lo compartas.
4. Abre tu bot nuevo, pulsa **Iniciar** y escríbele **hola**.

## 2. Crear el repositorio en GitHub
1. Entra en github.com con tu cuenta **eukillo-design**.
2. Arriba a la derecha, pulsa **+** → **New repository**.
3. Nombre: `vigilante-mahalo`.
4. Marca **Public**. (Así GitHub no cobra nada por las comprobaciones. Solo se verán los enlaces de las tiendas y el horario; el token de Telegram va aparte y nadie lo ve.)
5. Marca **Add a README file** y pulsa **Create repository**.

## 3. Subir los archivos
1. Descomprime el ZIP en tu ordenador.
2. En tu repositorio, pulsa **Add file** → **Upload files**.
3. Arrastra **todo el contenido** de la carpeta descomprimida (incluida la carpeta `.github`).
   - Si la carpeta `.github` no se ve (en Mac/Windows está oculta), mira el punto 3b.
4. Abajo, pulsa **Commit changes**.

### 3b. Si no te deja subir la carpeta `.github`
1. **Add file** → **Create new file**.
2. En el nombre escribe exactamente: `.github/workflows/vigilante.yml`
3. Abre el archivo `vigilante.yml` del ZIP con el Bloc de notas, copia todo y pégalo.
4. Pulsa **Commit changes**.

## 4. Guardar el token de Telegram como secreto
1. En tu repositorio: **Settings** → **Secrets and variables** → **Actions**.
2. **New repository secret**.
3. Name: `TELEGRAM_TOKEN` · Secret: pega el token de BotFather.
4. **Add secret**.

## 5. Primera prueba
1. Pestaña **Actions**. Si te pide activarlas, pulsa el botón verde para habilitarlas.
2. A la izquierda, pulsa **Vigilante Mahalo Bermejales** → **Run workflow** → **Run workflow**.
3. En 2–3 minutos te llegará a Telegram un mensaje **🧪 Prueba** con el estado de cada tienda.
4. Si algo sale como "desconocido", entra en la ejecución, baja hasta **Artifacts** → **capturas**, descárgalo y pásaselo a Claude para ajustarlo.

## Cómo funciona a partir de ahí
- Se comprueba solo cada 10 minutos, **solo** de 12:00 a 16:00 y de 19:30 a 23:00.
- Si una tienda deja de estar visible, te llega **⚠️** con una captura. Cuando vuelve, **✅**.
- Antes de avisar lo comprueba dos veces (con 45 segundos de diferencia) para no dar falsas alarmas.
- Si no consigue comprobar una tienda 3 veces seguidas, te llega **❓** para que la mires a mano.
- GitHub a veces retrasa unos minutos las ejecuciones en horas de mucho uso.

## Cambiar el horario o añadir tiendas
Abre `config.yaml` en GitHub, pulsa el lápiz ✏️, cambia lo que necesites y pulsa **Commit changes**.
